# Hasan Abbas Sorathiya — brand system

Everything here is derived from what already ships on [hasanabbassorathiya.tech](https://hasanabbassorathiya.tech): the paper-and-ink palette in `site/src/index.css`, the letterspaced `H S` boot monogram in `site/index.html`, and the self-hosted Geist / Geist Mono / Instrument Serif in `site/public/fonts/`. No new identity was invented — the existing one was specified.

## 1. Positioning

**Who it is for:** recruiters and founders evaluating a senior Flutter + AI engineer, and app users arriving from a store listing.

**The claim:** six years shipping real products for iOS and Android — apps in the stores, RAG systems, backends. Not a personal-brand abstraction; the evidence is the catalogue.

**The register:** a printed page. Paper, ink, hairline rules, one blue signal, one terracotta thread. Restraint reads as seniority; decoration reads as a template.

**Anti-pattern to avoid:** the site's own worst-possible version of itself — gradient glow, glassmorphism, generated ornament, mood imagery. If a layout could belong to any engineer's portfolio, it fails.

## 2. The mark

Two grotesque capitals, `H` then `S`, weight 600, uppercase, ~18% letterspacing.

The shipped SVG is **constructed geometry, not a font**: the `H` is three rectangles on an 18-unit stem, the `S` is two tangent 21-unit arcs stroked at 18. It renders identically in every browser, on every machine, with no font installed — which is why it survives a 16px favicon.

| File | Use |
| --- | --- |
| `brand/logo-mark.svg` | The bare monogram, `viewBox="-1 -1 175 104"`. `currentColor`, so it inherits ink or paper. |
| `brand/lockup-horizontal.svg` | Mark + hairline + name + role, `536 × 120`. Headers, letterheads, PDF cover. |
| `brand/seal-ink.svg` | Ink square, paper mark. Favicon, avatar, app icon. |
| `brand/seal-paper.svg` | Paper square, ink mark. On ink backgrounds only. |
| `brand/icons/` | `favicon-16.png`, `favicon-32.png`, `apple-touch-icon.png` (180), `icon-192.png`, `icon-512.png`. |
| `site/public/favicon.svg` | The ink seal with the mark enlarged to 81% of the box. Was violet `#14101F` + gold `#F1CF78` + Bricolage Grotesque — off-system, and the one asset that contradicted the site. Repo-only until the next deploy. |
| `site/public/{apple-touch-icon,icon-192,icon-512}.png` | Replaced with the new seal; `manifest.webmanifest` and `site/index.html` already point at these names, so no markup change is needed. |
| `site/public/brand/seal-ink.png` · `seal-paper.png` | 128px renders for the image variant of the email signature and any remote-avatar slot. |

Three construction details that are easy to get wrong and are already handled:

- The `S` arcs bulge past the letter box, so the ink runs from `y = -1` to `y = 101`. The viewBox carries 1 unit of bleed; a box tight to `0 0 171 100` clips the arc terminals.
- The crossbar overlaps each stem by 2 units (`x=17`, `width=48`). Same fill, so nothing shows — but abutting edges anti-alias against the ground and leave a visible seam inside the `H`.
- The lockup's `536` width is measured against Geist 600 at 23/12.5 with the tracking below. Without Geist the fallback shifts, so outline the two `<text>` nodes before sending to print.

**Rules**

- Clearspace on all four sides ≥ the cap height of the `H`.
- Ink on paper, or paper on ink. Never a third colour for the mark itself.
- No rotation, outline, drop shadow, gradient fill, or non-uniform scaling.
- Size floor: the seal reads at 32px. At 16 device pixels the `S` bowls collapse — browsers render `favicon.svg` as vector, so retina displays get the crisp 32px-equivalent, and `favicon-16.png` is only the legacy fallback. Below 32px, prefer the seal over the bare letters.

## 3. Colour

| Token | Hex | Role |
| --- | --- | --- |
| paper | `#F3EFE6` | Default canvas |
| surface | `#FBF8F2` | Cards, newsletter body |
| deep | `#E9E2D5` | Secondary ground, footer bands |
| ink | `#14110D` | Text and the mark |
| text | `#16130F` | Body copy |
| muted | `#665F52` | Labels, mono meta, rules' companion |
| signal | `#1D3CFF` | Links and one CTA. Never decoration. |
| thread | `#A33F1C` | Numbered lists, the rare warning |
| thread-soft | `#E08A5F` | Thread on ink grounds |

Hairlines are `rgba(22,19,15,.13)` at 1px. Dark mode inverts the grounds (`#12100C` canvas, `#F3EFE6` text) and softens signal to `#8B9BFF`.

**Discipline:** one accent per composition. If a screen has a blue CTA, the thread colour stays out.

## 4. Type

| Role | Face | Fallback for email/print |
| --- | --- | --- |
| Display, wordmark | Geist 600 | Helvetica Neue, Arial |
| Body | Geist 400 | Helvetica Neue, Arial |
| Labels, data, code | Geist Mono 400/600 | Menlo, Consolas, monospace |
| Editorial headlines | Instrument Serif italic | Georgia, Times New Roman |

Wordmark tracking `.18em`, uppercase. Mono labels uppercase at `.14–.18em`. Body measure 62–74 characters; never justify.

## 5. Voice

Short declarative sentences. Name the technology, the decision, and the consequence. Numbers only when they are real and attributable — the site has already had an unsubstantiated "100K+" removed once, and metrics carry their source. No "passionate", "guru", "ninja", "leverage", or "delve". First person for stories, third person for facts.

## 6. Applications

**Email signature** — `brand/email-signature.html`. Three variants (HTML clients, image-mark, plain text) in one file, with install steps for Gmail/Outlook/Apple Mail. The default variant draws the monogram as a solid ink cell with letterspaced text, so it survives blocked remote images. Deliberately absent: a phone number (not on file, never guessed), social icons, a headshot, a banner.

**Newsletter** — `brand/newsletter-template.html`, masthead **SHIPPING NOTES**. 600px table layout, inline styles, `{{TOKENS}}` for headline/body/notes/CTA/subscribe links. Nothing in the template asserts a subscriber count or a testimonial. *The name is a proposal, not a decision — say the word and it changes; the masthead is one string.*

**Boards** — `brand/boards/01…04.png`: overview, logo specification, newsletter system, signature applications. These are AI-rendered presentations of the system, so treat the SVG and HTML above as authoritative: the boards carry a few rendering artefacts (the overview's hex labels are mistyped, and the logo sheet picked up a stray "SIMPLE IDEAS FURTHER" line and a 2024 date). The mark, palette and lockups they show are the real ones.

## 7. Open, owner-side

1. Deploying the new `favicon.svg`, the three `site/public/*.png` icons and `site/public/brand/` to `public_html` — repo-only right now, and deploys need your approval.
2. The phone number for the signature, if you want one.
3. Whether `SHIPPING NOTES` is the name you want to live with.
4. Where dispatches are sent from (manual Gmail, or Beehiiv/Loops/Buttondown importing the template).
